recipes = [
    {
        "id": 1,
        "title": "Spaghetti Carbonara",
        "image_url": "/static/default_recipe.png",
        "ingredients": [
            "200g spaghetti",
            "100g pancetta",
            "2 eggs",
            "50g pecorino cheese",
            "Black pepper"
        ],
        "instructions": "Boil pasta. Fry pancetta. Mix eggs and cheese. Combine all."
    },
    {
        "id": 2,
        "title": "Veggie Curry",
        "image_url": "/static/default_recipe.png",
        "ingredients": [
            "2 carrots",
            "1 onion",
            "1 cup peas",
            "Spices",
            "Coconut milk"
        ],
        "instructions": "Sauté veggies. Add spices and coconut milk. Simmer until tender."
    }
]
